-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: viewdle
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `common`
--

DROP TABLE IF EXISTS `common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `common` (
  `common_seq` int NOT NULL AUTO_INCREMENT,
  `img_group` varchar(10) NOT NULL,
  `img_name` varchar(40) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  PRIMARY KEY (`common_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `common`
--

LOCK TABLES `common` WRITE;
/*!40000 ALTER TABLE `common` DISABLE KEYS */;
INSERT INTO `common` VALUES (2,'base_img','base_profile','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/base_image%2Fbase_profile.png?alt=media&token=3c3cd999-65bf-437b-af56-2f5aa3dcbeee'),(3,'base_img','base_badge','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/base_image%2Fbase_badge.PNG?alt=media&token=8f3a5805-5461-410a-b81c-8851e26bc8f8'),(4,'badges','bronze','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/badges%2Fbronze.png?alt=media&token=51b19cb0-7d9c-482a-8b64-f136a78c3468'),(5,'badges','silver','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/badges%2Fsilver.png?alt=media&token=75971351-0f9a-4a27-b689-73836403cacd'),(6,'badges','gold','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/badges%2Fgold.png?alt=media&token=b7f78a20-e05a-4a1e-a4fa-9979d8a62b51'),(7,'badges','platinum','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/badges%2Fplatinum.png?alt=media&token=5b5aa477-2962-4613-9498-26a1c7cd1225'),(8,'thumbnail','game','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/thumbnail%2Fgame.png?alt=media&token=a1b7e649-8e71-45a0-8109-59bc111a27b9'),(9,'thumbnail','study','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/thumbnail%2Fstudy.png?alt=media&token=e881a6c0-0441-4c68-870d-950f6bb4ed2e'),(10,'thumbnail','lock_game','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/thumbnail%2Flock_game.png?alt=media&token=58cd949a-4196-4270-9db1-e52902133942'),(11,'thumbnail','lock_study','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/thumbnail%2Flock_study.png?alt=media&token=fad17a2d-1e5f-47fe-ae16-ae50f30866a7'),(12,'filter','bread','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/filter%2Fbread_shape.png?alt=media&token=5fe3699b-17e1-4086-9cd1-53fa59cce6c9'),(13,'filter','potato','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/filter%2Fpotato_shape.png?alt=media&token=2426c722-cdb2-48af-8982-f17a16bd9e5e'),(14,'filter','bald','https://firebasestorage.googleapis.com/v0/b/viewdle-b6bf5.appspot.com/o/filter%2Fbald_remove.png?alt=media&token=5b340aed-24b0-4f9a-93aa-3abfa2b1b736');
/*!40000 ALTER TABLE `common` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18  2:34:22
